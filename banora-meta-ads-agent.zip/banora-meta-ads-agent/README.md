# Banora Meta Ads Agent

Full-pipeline Meta advertising agent for Banora Chiropractic with Telegram approval gating.

## What it does

Runs a weekly cycle that:

1. **Analyses** — Pulls last 7 days of Meta ad performance, evaluates each ad/adset against guardrails.
2. **Decides** — Claude proposes actions: pause underperformers, scale winners, launch new variants.
3. **Generates** — Drafts AHPRA-compliant ad copy variants for new tests.
4. **Approves** — Sends a single decision card to Telegram. James taps Approve / Edit / Reject.
5. **Executes** — On approval, applies all changes via the Meta Marketing API.
6. **Monitors** — Daily lightweight cron checks for guardrail breaches and pings Telegram if anything's off.

## Architecture

Same skeleton as `banora-social-autopilot`:

- **Vercel cron** — schedules the weekly planning job (Sun 8pm) and daily guardrail check (8am).
- **Claude API** (`claude-sonnet-4`) — analysis, decisions, copy generation.
- **Upstash Redis** — pending approvals, run history, decision audit log.
- **Telegram bot** — approval interface.
- **Meta Marketing API** — read performance, write changes (pause/scale/create).

## Project layout

```
src/
  lib/
    meta.ts            — Meta Marketing API client (read + write)
    claude.ts          — Anthropic SDK wrapper
    redis.ts           — Upstash client + key helpers
    telegram.ts        — Bot send + callback handler
    guardrails.ts      — Decision rules (CPL thresholds, frequency caps, learning periods)
  prompts/
    ahpra-system.ts    — AHPRA paid-ads compliance prompt
    analyst.ts         — Performance analysis prompt
    copywriter.ts      — Ad copy generation prompt
  jobs/
    weekly-plan.ts     — Sunday: analyse + propose + send approval card
    apply-decision.ts  — Triggered by Telegram callback: execute approved actions
    daily-check.ts     — Daily: scan for guardrail breaches
  types/
    meta.ts            — Meta API response types
    decisions.ts       — Decision schema (the JSON Claude must return)
api/
  cron/
    weekly-plan.ts     — Vercel cron entrypoint
    daily-check.ts     — Vercel cron entrypoint
  telegram/
    webhook.ts         — Telegram callback handler
```

## The AHPRA paid-ads constraint

Paid ads on Meta sit under stricter AHPRA rules than organic social:

- No testimonials (Section 133 of the National Law)
- No claims of "best", "leading", "top-rated", "most experienced"
- No before/after imagery for treatment outcomes
- No outcome guarantees or implied cures
- No fear-based copy ("don't ignore back pain or you'll need surgery")
- No targeting that could be seen as exploiting vulnerability

The system prompt enforces these as hard rules. Claude refuses to draft non-compliant copy and flags borderline cases for human review.

## Decision rules (configurable)

| Signal | Action |
|---|---|
| New ad, <3 days live | Hold (learning phase) |
| CPL > 2× target after 50 link clicks | Recommend pause |
| CTR < 0.8% after 1,000 impressions | Recommend pause |
| Frequency > 3.0 | Recommend creative refresh |
| CPL ≤ 0.7× target with stable spend | Recommend +30% budget |
| ROAS-equivalent (booking conversion) holding | Recommend +50% budget |

All thresholds live in `src/lib/guardrails.ts` and are easy to tune as data accumulates.

## Setup

Environment variables required:

```
ANTHROPIC_API_KEY=
META_ACCESS_TOKEN=               # long-lived system user token
META_AD_ACCOUNT_ID=              # act_XXXXXXXX
META_PAGE_ID=                    # Banora FB page
META_INSTAGRAM_ACTOR_ID=         # Banora IG account
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=                # James's chat
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=
TARGET_CPL_AUD=45                # tune this — what's a viable cost per lead
```

## Status

This repo is the skeleton. Currently wired:

- ✅ Read insights from Meta (last 7 days, ad-level)
- ✅ Guardrail-based default decisions
- ✅ Claude analyst pass with override
- ✅ AHPRA-compliant copy generation for new variants
- ✅ Telegram approval card
- ✅ Pause / refresh execution on approval
- ✅ Adset budget changes (scale up/down) with safety clamps and adset-level deduplication
- ✅ Edit flow — reply to Telegram in plain English to revise the plan, with diff and iterative re-edits
- ✅ New ad creation from approved copy + creative library + Claude-picked adsets, all launching paused
- ⏳ CTR week-over-week trend (currently stubbed as 'stable')
- ⏳ Telegram-native creative upload flow (today: CLI in `scripts/library.ts`)

To go live:

1. Generate a long-lived Meta system user token with `ads_management`, `pages_manage_ads`, `business_management` scopes.
2. Wire the Telegram webhook to `/api/telegram/webhook`.
3. Deploy to Vercel, set crons in `vercel.json`.
4. Upload at least one approved image or video to the creative library (see below) — without this, new variants can't be created.
5. Run with `DRY_RUN=true` for 2 weeks to validate decisions before turning on writes.

## Creative library

The agent only creates ads using creatives you've explicitly approved. The library lives in Redis and is managed via a CLI:

```bash
# Upload an image to Meta first to get its hash:
curl -F "filename=@my-image.jpg" \
  "https://graph.facebook.com/v21.0/act_XXX/adimages?access_token=$META_ACCESS_TOKEN"
# → { "images": { "my-image.jpg": { "hash": "abc123..." } } }

# Add to library (status: pending):
npx tsx scripts/library.ts add image abc123 \
  --label "James in clinic, wide" \
  --tags "james,clinic,professional,square" \
  --source "in-house" \
  --aspect 1:1

# Review and approve:
npx tsx scripts/library.ts list pending
npx tsx scripts/library.ts approve cre_a1b2c3d4
```

Videos work the same way — upload via `/act_X/advideos`, then `add video <video_id> ...`.

Tag conventions (free-form but consistent helps Claude pick well):
- audience: `desk-workers`, `tradies`, `parents`, `general`
- subject: `james`, `paul`, `clinic`, `lifestyle`
- mood: `calm`, `energetic`, `professional`
- format: `square`, `vertical`, `horizontal`
- condition: `low-back`, `neck`, `headaches`, `general`

When the agent drafts a new variant, it asks Claude to map each variant's brief to the best matching adset (active adsets in the account) and the best matching creative (approved entries in the library), with a confidence score. Confidence below 0.6 → variant is flagged on the approval card and skipped at creation time so you can pick manually.

## Edit flow

When a weekly approval card lands in Telegram, James has three buttons:

- **Approve all** — applies the plan as-is, including creating any new variants (paused).
- **Edit** — pins the chat to this run for 30 minutes. James's next plain-text message gets sent to Claude as edit instructions. Claude returns a revised plan and the bot sends a new card showing exactly what changed. If edits change the new variant briefs, copy and placements are regenerated automatically.
- **Reject** — discards the run, no changes applied.

`/cancel` exits edit mode. `/status` shows what run (if any) is currently pinned.

## Tests

Pure-function logic has unit tests in `src/lib/__tests__/` and `src/jobs/__tests__/`:

```
npx tsx src/lib/__tests__/guardrails.test.ts     # budget clamping
npx tsx src/jobs/__tests__/apply-decision.test.ts # most-conservative aggregation
npx tsx src/lib/__tests__/diff-plans.test.ts      # plan diff utility
npx tsc --noEmit                                  # full type check
```

20/20 tests passing as of the latest commit.
