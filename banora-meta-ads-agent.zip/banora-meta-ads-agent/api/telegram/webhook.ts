/**
 * Telegram webhook.
 *
 * Handles two kinds of update:
 *
 *   1. callback_query — James tapped Approve / Edit / Reject on a card.
 *   2. message        — James sent a plain-text message. If we have a
 *      pinned awaiting-edit run for his chat, we treat the message as
 *      edit instructions; otherwise we ignore it (or respond to /cancel).
 *
 * Set up: in BotFather → setWebhook → https://<your-vercel-domain>/api/telegram/webhook
 *
 * We answer callbacks immediately (Telegram requires <15s) and run the
 * actual work after — Vercel keeps the function alive long enough for a
 * typical apply or revise pass (a few seconds).
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { applyDecision, rejectDecision } from '../../src/jobs/apply-decision';
import { revisePlan, cancelEdit } from '../../src/jobs/revise-plan';
import { sendPlain } from '../../src/lib/telegram';
import { redis, keys, AWAITING_EDIT_TTL_SECONDS } from '../../src/lib/redis';

interface TelegramUpdate {
  callback_query?: {
    id: string;
    from: { id: number };
    data: string;
    message?: { chat: { id: number } };
  };
  message?: {
    chat: { id: number };
    text?: string;
  };
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const update = req.body as TelegramUpdate;
  const expectedChatId = process.env.TELEGRAM_CHAT_ID;

  // ── Callback queries (button taps) ───────────────────────────────────
  if (update.callback_query) {
    const cb = update.callback_query;
    if (cb.message && String(cb.message.chat.id) !== expectedChatId) {
      return res.status(403).json({ error: 'wrong chat' });
    }

    // Acknowledge immediately so Telegram stops the spinner
    await fetch(
      `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/answerCallbackQuery`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callback_query_id: cb.id }),
      },
    );

    const [action, runId] = cb.data.split(':');

    try {
      switch (action) {
        case 'approve':
          // If James was mid-edit, clear the pin — approve takes precedence.
          if (expectedChatId) await redis.del(keys.awaitingEdit(expectedChatId));
          await applyDecision(runId);
          break;

        case 'reject':
          if (expectedChatId) await redis.del(keys.awaitingEdit(expectedChatId));
          await rejectDecision(runId);
          break;

        case 'edit':
          if (!expectedChatId) {
            await sendPlain('TELEGRAM_CHAT_ID not configured — edit flow disabled.');
            break;
          }
          await redis.set(keys.awaitingEdit(expectedChatId), runId, {
            ex: AWAITING_EDIT_TTL_SECONDS,
          });
          await sendPlain(
            `✏️ Editing run \`${runId.slice(0, 8)}\`. Reply with what you want changed — be specific. Examples:\n\n• "Don't pause Ad 3, the CTR is fine"\n• "Scale Ad 2 by 20% not 30%"\n• "Drop the new variants for now"\n\nSend /cancel to bail out. Window: 30 min.`,
          );
          break;

        default:
          await sendPlain(`Unknown action: ${action}`);
      }
    } catch (err) {
      await sendPlain(`Error handling ${action}: ${err instanceof Error ? err.message : String(err)}`);
    }

    return res.status(200).json({ ok: true });
  }

  // ── Plain-text messages ──────────────────────────────────────────────
  if (update.message?.text) {
    const msg = update.message;
    if (String(msg.chat.id) !== expectedChatId) {
      return res.status(403).json({ error: 'wrong chat' });
    }

    const text = msg.text!.trim();

    // /cancel — leave edit mode if pinned
    if (text === '/cancel') {
      if (expectedChatId) await cancelEdit(expectedChatId);
      else await sendPlain('Nothing to cancel.');
      return res.status(200).json({ ok: true });
    }

    // /status — quick state peek (handy for debugging on phone)
    if (text === '/status') {
      const pinnedRun = expectedChatId
        ? await redis.get<string>(keys.awaitingEdit(expectedChatId))
        : null;
      const lastRun = await redis.get<string>(keys.lastRun());
      await sendPlain(
        `*Status*\nLast run: \`${(lastRun ?? 'none').slice(0, 8)}\`\nAwaiting edit on: \`${(pinnedRun ?? 'none').slice(0, 8)}\``,
      );
      return res.status(200).json({ ok: true });
    }

    // Edit instructions — only if we're pinned to a run
    const pinnedRunId = expectedChatId
      ? await redis.get<string>(keys.awaitingEdit(expectedChatId))
      : null;

    if (pinnedRunId) {
      try {
        await revisePlan({ runId: pinnedRunId, instructions: text });
      } catch (err) {
        await sendPlain(`Edit failed: ${err instanceof Error ? err.message : String(err)}`);
      }
      return res.status(200).json({ ok: true });
    }

    // Otherwise: ignore. The bot isn't a chatbot — it only responds when
    // James has explicitly entered edit mode or used a command.
    return res.status(200).json({ ok: true });
  }

  return res.status(200).json({ ok: true });
}
