/**
 * Vercel cron entrypoint — weekly plan.
 * Wired in vercel.json to run Sundays 8pm AEST (10:00 UTC).
 *
 * Protected by CRON_SECRET so only Vercel's cron can hit it.
 */

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { runWeeklyPlan } from '../../src/jobs/weekly-plan';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'unauthorised' });
  }
  try {
    const { runId } = await runWeeklyPlan();
    return res.status(200).json({ ok: true, runId });
  } catch (err) {
    console.error('weekly-plan failed', err);
    return res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
}
