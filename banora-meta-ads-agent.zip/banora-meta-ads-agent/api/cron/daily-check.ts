import type { VercelRequest, VercelResponse } from '@vercel/node';
import { runDailyCheck } from '../../src/jobs/daily-check';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'unauthorised' });
  }
  try {
    await runDailyCheck();
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('daily-check failed', err);
    return res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
  }
}
