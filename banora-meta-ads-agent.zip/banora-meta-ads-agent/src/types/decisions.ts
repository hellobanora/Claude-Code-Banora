/**
 * Decision schema — the JSON contract between Claude (analyst/copywriter)
 * and the executor that calls the Meta API.
 *
 * If Claude returns malformed JSON, the executor refuses to run and pings
 * Telegram with the parse error. We never partially apply a decision set.
 */

export type AdAction = 'hold' | 'pause' | 'scale_up' | 'scale_down' | 'refresh';

export interface AdDecision {
  ad_id: string;
  ad_name: string;
  action: AdAction;
  budget_change_pct: number | null;
  reason: string;
}

export interface NewVariantBrief {
  angle: string;
  rationale: string;
  audience_hint: string;
  objective: 'BookingStarted' | 'BookingCompleted';
}

export interface HeadlineMetrics {
  spend_aud: number;
  link_clicks: number;
  bookings_started: number;
  bookings_completed: number;
  blended_cpl_aud: number;
  vs_last_week: 'improving' | 'stable' | 'declining';
}

export interface AnalystOutput {
  summary: string;
  headline_metrics: HeadlineMetrics;
  ad_decisions: AdDecision[];
  new_variant_briefs: NewVariantBrief[];
  flags_for_human: string[];
}

export type CallToAction = 'BOOK_NOW' | 'LEARN_MORE' | 'CONTACT_US';

export interface CopyVariant {
  label: string;
  primary_text: string;
  headline: string;
  description: string;
  cta: CallToAction;
  compliance_notes: string;
}

export interface CopywriterOutput {
  variants: CopyVariant[];
  rejected_angles: Array<{ angle: string; reason: string }>;
}

/**
 * One placement decision: which adset will host the new variant, and
 * which creative asset will back it. Aligned by index with the
 * AnalystOutput.new_variant_briefs array and CopywriterOutput.variants.
 */
export interface Placement {
  brief_index: number;
  adset_id: string | null;
  adset_name: string | null;
  creative_asset_id: string | null;
  creative_label: string | null;
  confidence: number;        // 0-1
  reasoning: string;
  human_review_reason: string | null;
}

export interface PlacementOutput {
  placements: Placement[];
}

/**
 * Result of attempting to create one new ad on Meta.
 */
export interface NewAdResult {
  brief_index: number;
  brief_label: string;
  success: boolean;
  meta_ad_id?: string;
  meta_creative_id?: string;
  detail?: string;
  error?: string;
}

/**
 * The editor's response when James revises a plan via plain-text reply.
 */
export interface EditorOutput {
  revised_plan: AnalystOutput;
  changes_applied: Array<{ what: string; why: string }>;
  unresolved_questions: string[];
}

/**
 * One pass of edits applied to a pending decision. Multiple revisions
 * accumulate in PendingDecision.edits in the order they happened.
 */
export interface EditRecord {
  at: string;
  instructions: string;
  changes_applied: Array<{ what: string; why: string }>;
  unresolved_questions: string[];
}

/**
 * Lightweight snapshot of an ad at decision time — just enough for the
 * executor to look up adset_id from ad_id and to know the current budget
 * (so we can detect concurrent edits between proposal and approval).
 */
export interface InsightsSnapshot {
  ad_id: string;
  adset_id: string;
  ad_name: string;
  spend_aud_7d: number;
}

/**
 * The full pending decision stored in Redis between proposal and approval.
 * One key per pending run: `pending:<run_id>`.
 */
export interface PendingDecision {
  run_id: string;
  created_at: string;
  insights_snapshot: InsightsSnapshot[];
  analyst_output: AnalystOutput;
  /** Snapshot of the very first analyst_output, before any edits. */
  original_analyst_output?: AnalystOutput;
  /** Each entry is one round of revision via the edit flow. */
  edits?: EditRecord[];
  generated_copy: CopywriterOutput | null;
  /** Placements for new variants — adset and creative chosen per brief. */
  placements: PlacementOutput | null;
  status:
    | 'awaiting_approval'
    | 'awaiting_edit'
    | 'approved'
    | 'rejected'
    | 'edited'
    | 'applied';
  approved_at?: string;
  applied_at?: string;
  applied_results?: Array<{
    target_id: string;     // ad_id for pause/refresh, adset_id for budget changes
    target_kind: 'ad' | 'adset';
    action: AdAction;
    success: boolean;
    detail?: string;       // e.g. "budget 4000 -> 5200 cents"
    error?: string;
  }>;
  /** Outcomes of new-variant ad creation, populated by the executor. */
  new_ads_results?: NewAdResult[];
}
