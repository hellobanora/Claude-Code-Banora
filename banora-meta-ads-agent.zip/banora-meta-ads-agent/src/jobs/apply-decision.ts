/**
 * Apply an approved decision set to Meta.
 *
 * Triggered from the Telegram webhook after James taps "Approve all".
 * Reads the PendingDecision from Redis, walks the actions, and writes
 * to Meta. Reports a summary back to Telegram.
 *
 * Failures are non-fatal at the per-target level — we collect errors and
 * apply everything we can, then report what failed.
 *
 * Budget changes are deduplicated by adset_id: if two ads in the same
 * adset both get scale_up, the budget is changed once. If they conflict
 * (one up, one down), we skip the adset and flag it for the human.
 */

import { redis, keys } from '../lib/redis';
import {
  pauseAd,
  getAdsetDailyBudgetCents,
  setAdsetDailyBudgetCents,
  createImageAd,
  createVideoAd,
} from '../lib/meta';
import { getAsset } from '../lib/creative-library';
import { computeClampedBudget, DEFAULT_GUARDRAILS } from '../lib/guardrails';
import { sendPlain } from '../lib/telegram';
import type { AdAction, NewAdResult, PendingDecision } from '../types/decisions';

const BOOKING_LINK = 'https://banorachiro.com.au/book';

const MIN_PLACEMENT_CONFIDENCE = 0.6;

type ResultEntry = NonNullable<PendingDecision['applied_results']>[number];

/**
 * From a set of agreed-direction percentage changes, pick the smallest
 * magnitude — the most conservative move. Exported for unit testing.
 *
 * Assumes all values share a sign (the caller checks for conflict first).
 */
export function pickMostConservativePct(changes: number[]): number {
  if (changes.length === 0) throw new Error('pickMostConservativePct: empty array');
  return changes.reduce(
    (smallest, next) => (Math.abs(next) < Math.abs(smallest) ? next : smallest),
    changes[0],
  );
}

export async function applyDecision(runId: string): Promise<void> {
  const pending = (await redis.get(keys.pending(runId))) as PendingDecision | null;
  if (!pending) {
    await sendPlain(`⚠️ Run \`${runId.slice(0, 8)}\` not found or expired. Nothing applied.`);
    return;
  }
  if (pending.status === 'applied') {
    await sendPlain(`Run \`${runId.slice(0, 8)}\` was already applied. Skipping.`);
    return;
  }

  const dryRun = process.env.DRY_RUN === 'true';
  const results: ResultEntry[] = [];

  // Build lookup: ad_id → adset_id from the snapshot taken at decision time.
  const adsetByAd = new Map<string, string>();
  const adNameByAd = new Map<string, string>();
  for (const snap of pending.insights_snapshot) {
    adsetByAd.set(snap.ad_id, snap.adset_id);
    adNameByAd.set(snap.ad_id, snap.ad_name);
  }

  // ── Pass 1: ad-level actions (pause, refresh) ────────────────────────
  for (const d of pending.analyst_output.ad_decisions) {
    if (d.action !== 'pause' && d.action !== 'refresh') continue;
    try {
      // Both pause and refresh start by pausing the ad. Refresh additionally
      // implies new variants will run in the same adset — those are created
      // separately once an image library is wired up.
      await pauseAd(d.ad_id, dryRun);
      results.push({
        target_id: d.ad_id,
        target_kind: 'ad',
        action: d.action,
        success: true,
        detail: d.action === 'refresh' ? 'paused; new variants pending' : 'paused',
      });
    } catch (err) {
      results.push({
        target_id: d.ad_id,
        target_kind: 'ad',
        action: d.action,
        success: false,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  // ── Pass 2: aggregate scale_up / scale_down by adset_id ──────────────
  // If the same adset has multiple ads with budget actions, we resolve to
  // a single adset-level decision.
  const adsetActions = new Map<
    string,
    { changes: number[]; conflict: boolean; sourceAds: string[] }
  >();

  for (const d of pending.analyst_output.ad_decisions) {
    if (d.action !== 'scale_up' && d.action !== 'scale_down') continue;
    if (d.budget_change_pct === null) continue;

    const adsetId = adsetByAd.get(d.ad_id);
    if (!adsetId) {
      results.push({
        target_id: d.ad_id,
        target_kind: 'ad',
        action: d.action,
        success: false,
        error: 'adset_id not found in snapshot — ad may have been deleted',
      });
      continue;
    }

    const existing = adsetActions.get(adsetId);
    if (!existing) {
      adsetActions.set(adsetId, {
        changes: [d.budget_change_pct],
        conflict: false,
        sourceAds: [d.ad_id],
      });
    } else {
      // Conflict if signs differ (one up, one down)
      const sameSign =
        Math.sign(existing.changes[0]) === Math.sign(d.budget_change_pct);
      existing.changes.push(d.budget_change_pct);
      existing.sourceAds.push(d.ad_id);
      existing.conflict = existing.conflict || !sameSign;
    }
  }

  // ── Pass 3: apply adset budget changes ───────────────────────────────
  for (const [adsetId, agg] of adsetActions) {
    if (agg.conflict) {
      results.push({
        target_id: adsetId,
        target_kind: 'adset',
        action: 'scale_up',
        success: false,
        error: `Conflicting budget signals from ads ${agg.sourceAds.join(', ')} — skipped, review manually`,
      });
      continue;
    }

    // When multiple ads in the same adset agree on direction, take the
    // smallest magnitude — the most conservative move. e.g. +30% and +50%
    // → +30%. This errs toward gentle scaling rather than compounding
    // aggressive bets across noisy small samples.
    const requestedPct = pickMostConservativePct(agg.changes);
    const action: AdAction = requestedPct >= 0 ? 'scale_up' : 'scale_down';

    try {
      const currentCents = await getAdsetDailyBudgetCents(adsetId);
      if (currentCents === null) {
        results.push({
          target_id: adsetId,
          target_kind: 'adset',
          action,
          success: false,
          error: 'Adset uses lifetime/CBO budget — daily budget change not applicable',
        });
        continue;
      }

      const clamped = computeClampedBudget(currentCents, requestedPct, DEFAULT_GUARDRAILS);
      await setAdsetDailyBudgetCents(adsetId, clamped.new_cents, dryRun);

      const sign = clamped.effective_change_pct >= 0 ? '+' : '';
      const detail =
        `$${clamped.current_aud.toFixed(0)} → $${clamped.new_aud.toFixed(0)}/day ` +
        `(${sign}${clamped.effective_change_pct.toFixed(0)}%)` +
        (clamped.was_clamped ? ` _${clamped.clamp_reason}_` : '');

      results.push({
        target_id: adsetId,
        target_kind: 'adset',
        action,
        success: true,
        detail,
      });
    } catch (err) {
      results.push({
        target_id: adsetId,
        target_kind: 'adset',
        action,
        success: false,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  // ── Pass 4: create new variant ads on Meta ───────────────────────────
  // Skipped if there are no placements, or if placement confidence is
  // below the threshold for any individual variant. Variants without a
  // valid placement are flagged in the report but never silently dropped.
  const newAdsResults: NewAdResult[] = [];

  if (
    pending.generated_copy &&
    pending.placements &&
    pending.generated_copy.variants.length > 0
  ) {
    for (let i = 0; i < pending.generated_copy.variants.length; i++) {
      const variant = pending.generated_copy.variants[i];
      const placement = pending.placements.placements.find((p) => p.brief_index === i);

      // No placement at all
      if (!placement) {
        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: false,
          error: 'No placement record found for this variant',
        });
        continue;
      }

      // Low confidence — skip and surface
      if (placement.confidence < MIN_PLACEMENT_CONFIDENCE) {
        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: false,
          error:
            `Placement confidence ${(placement.confidence * 100).toFixed(0)}% < ${(MIN_PLACEMENT_CONFIDENCE * 100).toFixed(0)}% — skipped (${placement.human_review_reason ?? 'review manually'})`,
        });
        continue;
      }

      // Missing adset or asset id
      if (!placement.adset_id || !placement.creative_asset_id) {
        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: false,
          error: `Missing ${!placement.adset_id ? 'adset_id' : 'creative_asset_id'} — ${placement.human_review_reason ?? 'review manually'}`,
        });
        continue;
      }

      // Look up the asset to know whether it's an image or a video
      const asset = await getAsset(placement.creative_asset_id);
      if (!asset) {
        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: false,
          error: `Creative asset ${placement.creative_asset_id} not found in library`,
        });
        continue;
      }
      if (asset.status !== 'approved') {
        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: false,
          error: `Creative asset ${asset.id} is ${asset.status}, not approved`,
        });
        continue;
      }

      // Build a stable, descriptive ad name. Includes runId prefix so
      // ads from this run are easy to find in Ads Manager later.
      const adName = `[${runId.slice(0, 8)}] ${variant.label}`;

      try {
        const baseArgs = {
          adsetId: placement.adset_id,
          name: adName,
          primary_text: variant.primary_text,
          headline: variant.headline,
          description: variant.description,
          cta: variant.cta,
          link_url: BOOKING_LINK,
          dryRun,
        };

        const result =
          asset.kind === 'image'
            ? await createImageAd({ ...baseArgs, image_hash: asset.meta_ref })
            : await createVideoAd({ ...baseArgs, video_id: asset.meta_ref });

        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: true,
          meta_ad_id: result?.ad_id,
          meta_creative_id: result?.creative_id,
          detail: `${asset.kind} ad in ${placement.adset_name} (PAUSED)`,
        });
      } catch (err) {
        newAdsResults.push({
          brief_index: i,
          brief_label: variant.label,
          success: false,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }
  }

  // ── Persist final state ──────────────────────────────────────────────
  pending.status = 'applied';
  pending.applied_at = new Date().toISOString();
  pending.applied_results = results;
  pending.new_ads_results = newAdsResults;
  await redis.set(keys.pending(runId), pending);
  await redis.set(keys.history(runId), pending);

  // ── Report back to Telegram ──────────────────────────────────────────
  const successes = results.filter((r) => r.success);
  const failures = results.filter((r) => !r.success);

  const lines: string[] = [
    `*Applied run \`${runId.slice(0, 8)}\`*${dryRun ? ' _(dry-run)_' : ''}`,
    `${successes.length}/${results.length} actions succeeded.`,
  ];

  if (successes.length > 0) {
    lines.push('');
    lines.push('*Succeeded:*');
    for (const r of successes) {
      const name = r.target_kind === 'ad' ? adNameByAd.get(r.target_id) : `adset ${r.target_id}`;
      lines.push(`✓ ${r.action} — ${name}${r.detail ? ` · ${r.detail}` : ''}`);
    }
  }

  if (failures.length > 0) {
    lines.push('');
    lines.push('*Failed:*');
    for (const r of failures) {
      const name =
        r.target_kind === 'ad' ? adNameByAd.get(r.target_id) ?? r.target_id : `adset ${r.target_id}`;
      lines.push(`✗ ${r.action} — ${name}: ${r.error}`);
    }
  }

  // New variant ads created (separate section so they're scannable)
  if (newAdsResults.length > 0) {
    const adsCreated = newAdsResults.filter((r) => r.success);
    const adsFailed = newAdsResults.filter((r) => !r.success);

    lines.push('');
    lines.push(`*New variants:* ${adsCreated.length}/${newAdsResults.length} created (PAUSED)`);

    if (adsCreated.length > 0) {
      lines.push('_Review in Ads Manager and enable when ready._');
      for (const r of adsCreated) {
        lines.push(`✓ ${r.brief_label}${r.detail ? ` · ${r.detail}` : ''}`);
      }
    }
    if (adsFailed.length > 0) {
      lines.push('');
      lines.push('*Variants not created:*');
      for (const r of adsFailed) {
        lines.push(`✗ ${r.brief_label}: ${r.error}`);
      }
    }
  }

  await sendPlain(lines.join('\n'));
}

export async function rejectDecision(runId: string): Promise<void> {
  const pending = (await redis.get(keys.pending(runId))) as PendingDecision | null;
  if (!pending) return;
  pending.status = 'rejected';
  await redis.set(keys.pending(runId), pending);
  await sendPlain(`Run \`${runId.slice(0, 8)}\` rejected. No changes applied.`);
}
