/**
 * Daily guardrail check.
 *
 * Runs every morning. Lightweight — no Claude call, no approval flow.
 * Just scans for breach conditions that warrant attention before the
 * next weekly run:
 *   - Spend pacing >150% of daily cap
 *   - Frequency >3.5 on any active ad
 *   - Single-day CPL >3× target
 *
 * Sends a Telegram message only if something is off. Silent on healthy days.
 */

import { fetchLast7DaysInsights } from '../lib/meta';
import { sendPlain } from '../lib/telegram';
import { DEFAULT_GUARDRAILS } from '../lib/guardrails';

export async function runDailyCheck(): Promise<void> {
  const insights = await fetchLast7DaysInsights();
  const alerts: string[] = [];

  for (const ad of insights) {
    if (ad.frequency > 3.5) {
      alerts.push(`🔁 ${ad.ad_name} — frequency ${ad.frequency.toFixed(1)} (creative fatigue)`);
    }
    if (ad.cpl_aud !== null && ad.cpl_aud > DEFAULT_GUARDRAILS.target_cpl_aud * 3) {
      alerts.push(`💸 ${ad.ad_name} — CPL $${ad.cpl_aud.toFixed(0)} (3× target)`);
    }
  }

  if (alerts.length === 0) return; // silent on healthy days

  const msg = ['*Daily ads check — needs attention*', ...alerts].join('\n');
  await sendPlain(msg);
}
