/**
 * Revise an existing pending decision based on James's plain-text edit
 * instructions, then send a new approval card with a diff of what changed.
 *
 * Triggered from the Telegram webhook when James is in awaiting_edit
 * state and sends a non-command text message.
 */

import { redis, keys, PENDING_TTL_SECONDS } from '../lib/redis';
import { generateJson } from '../lib/claude';
import { listActiveAdsets } from '../lib/meta';
import { listApprovedAssets } from '../lib/creative-library';
import { sendApprovalCard, sendPlain, formatDecisionCard } from '../lib/telegram';
import { diffPlans } from '../lib/diff-plans';
import { EDITOR_SYSTEM_PROMPT } from '../prompts/editor';
import { AHPRA_PAID_ADS_SYSTEM_PROMPT } from '../prompts/ahpra-system';
import { PLACEMENT_SYSTEM_PROMPT } from '../prompts/placement';
import type {
  CopywriterOutput,
  EditorOutput,
  PendingDecision,
  PlacementOutput,
} from '../types/decisions';

export async function revisePlan(args: {
  runId: string;
  instructions: string;
}): Promise<void> {
  const pending = (await redis.get(keys.pending(args.runId))) as PendingDecision | null;
  if (!pending) {
    await sendPlain(`⚠️ Run \`${args.runId.slice(0, 8)}\` not found or expired. Edit cancelled.`);
    return;
  }
  if (pending.status === 'applied' || pending.status === 'rejected') {
    await sendPlain(
      `Run \`${args.runId.slice(0, 8)}\` is already ${pending.status}. Edit ignored.`,
    );
    return;
  }

  // Ask Claude to revise — pass the *current* plan, not the original.
  // This means iterative edits work correctly: each round revises the
  // plan as it stood at the start of that round.
  const userMsg = JSON.stringify(
    {
      original_plan: pending.analyst_output,
      edit_instructions: args.instructions,
    },
    null,
    2,
  );

  let editorOutput: EditorOutput;
  try {
    editorOutput = await generateJson<EditorOutput>({
      system: EDITOR_SYSTEM_PROMPT,
      user: userMsg,
      maxTokens: 4000,
    });
  } catch (err) {
    await sendPlain(
      `❌ Couldn't apply your edit — Claude returned malformed output.\n\n_${err instanceof Error ? err.message : String(err)}_\n\nThe original plan is unchanged. Try rephrasing the edit, or tap Approve / Reject on the previous card.`,
    );
    return;
  }

  // If no changes were applied AND no questions came back, something's off.
  if (editorOutput.changes_applied.length === 0 && editorOutput.unresolved_questions.length === 0) {
    await sendPlain(
      `Hmm — I couldn't identify a concrete change in your message. The original plan is unchanged. Try being more specific (e.g. "don't pause Ad 3" or "scale Ad 2 by 20% not 30%").`,
    );
    return;
  }

  // Compute diff against the *previous* analyst_output before we overwrite it.
  const diff = diffPlans(pending.analyst_output, editorOutput.revised_plan);

  // If new_variant_briefs changed (count or content), the existing copy
  // and placements are stale. Re-run them so the executor doesn't apply
  // mismatched copy or wrong placements. Detection: compare angle strings.
  const oldAngles = pending.analyst_output.new_variant_briefs.map((v) => v.angle).join('|');
  const newAngles = editorOutput.revised_plan.new_variant_briefs.map((v) => v.angle).join('|');
  const briefsChanged = oldAngles !== newAngles;

  if (briefsChanged) {
    if (editorOutput.revised_plan.new_variant_briefs.length === 0) {
      // James removed all new variants — clear copy and placements.
      pending.generated_copy = null;
      pending.placements = null;
    } else {
      // Briefs changed — regenerate copy, then re-run placement.
      pending.generated_copy = await generateJson<CopywriterOutput>({
        system: AHPRA_PAID_ADS_SYSTEM_PROMPT,
        user: `Draft ad copy variants for these briefs. Return one variant per brief.\n\nBriefs:\n${JSON.stringify(editorOutput.revised_plan.new_variant_briefs, null, 2)}`,
        maxTokens: 3000,
      });

      const [adsets, creatives] = await Promise.all([
        listActiveAdsets(),
        listApprovedAssets(),
      ]);

      if (creatives.length === 0) {
        editorOutput.revised_plan.flags_for_human.push(
          '⚠️ No approved creatives in the library — new variants drafted but cannot be created until you approve creative assets.',
        );
        pending.placements = null;
      } else {
        const placementUserMsg = JSON.stringify(
          {
            variant_briefs: editorOutput.revised_plan.new_variant_briefs,
            variant_copy: pending.generated_copy.variants,
            adsets,
            creative_assets: creatives.map((a) => ({
              id: a.id,
              kind: a.kind,
              label: a.label,
              tags: a.tags,
              aspect_ratio: a.aspect_ratio,
            })),
          },
          null,
          2,
        );
        pending.placements = await generateJson<PlacementOutput>({
          system: PLACEMENT_SYSTEM_PROMPT,
          user: placementUserMsg,
          maxTokens: 2000,
        });
      }
    }
  }

  // Persist: keep the very first plan as original_analyst_output, append
  // this edit to the edits array, replace the working analyst_output.
  if (!pending.original_analyst_output) {
    pending.original_analyst_output = pending.analyst_output;
  }
  pending.edits = pending.edits ?? [];
  pending.edits.push({
    at: new Date().toISOString(),
    instructions: args.instructions,
    changes_applied: editorOutput.changes_applied,
    unresolved_questions: editorOutput.unresolved_questions,
  });
  pending.analyst_output = editorOutput.revised_plan;
  pending.status = 'awaiting_approval';

  await redis.set(keys.pending(args.runId), pending, { ex: PENDING_TTL_SECONDS });

  // Clear the awaiting-edit pin — James's next message shouldn't be
  // treated as a further edit unless he taps Edit again.
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (chatId) await redis.del(keys.awaitingEdit(chatId));

  // Build the revised card. Lead with the diff so it's the first thing
  // James reads — the rest is the same shape as the original card so
  // re-approving feels familiar.
  const baseCard = formatDecisionCard({
    runId: args.runId,
    summary: editorOutput.revised_plan.summary,
    spend: editorOutput.revised_plan.headline_metrics.spend_aud,
    bookings: editorOutput.revised_plan.headline_metrics.bookings_started,
    cpl: editorOutput.revised_plan.headline_metrics.blended_cpl_aud,
    trend: editorOutput.revised_plan.headline_metrics.vs_last_week,
    decisions: editorOutput.revised_plan.ad_decisions
      .filter((d) => d.action !== 'hold')
      .map((d) => ({ ad_name: d.ad_name, action: d.action, reason: d.reason })),
    newVariants: editorOutput.revised_plan.new_variant_briefs.length,
    flags: editorOutput.revised_plan.flags_for_human,
  });

  const diffSection: string[] = [];
  diffSection.push(`*Revised — round ${pending.edits.length}*`);
  if (diff.length > 0) {
    diffSection.push('_Changes from previous version:_');
    for (const c of diff) diffSection.push(`• ${c}`);
  } else {
    diffSection.push('_No structural changes — only reasons updated._');
  }

  if (editorOutput.unresolved_questions.length > 0) {
    diffSection.push('');
    diffSection.push('*⚠️ Unresolved:*');
    for (const q of editorOutput.unresolved_questions) diffSection.push(`• ${q}`);
  }

  diffSection.push('');
  await sendApprovalCard({
    runId: args.runId,
    text: `${diffSection.join('\n')}\n──────\n\n${baseCard}`,
  });
}

export async function cancelEdit(chatId: string): Promise<void> {
  await redis.del(keys.awaitingEdit(chatId));
  await sendPlain('Edit cancelled. The previous plan is still pending.');
}
