/**
 * Tests for pickMostConservativePct.
 * Run with: npx tsx src/jobs/__tests__/apply-decision.test.ts
 */

import { pickMostConservativePct } from '../apply-decision';

interface Case {
  name: string;
  input: number[];
  expected: number;
}

const cases: Case[] = [
  { name: 'single value', input: [30], expected: 30 },
  { name: 'two scale-ups, smaller wins',  input: [30, 50],   expected: 30 },
  { name: 'three scale-ups, smallest wins', input: [50, 30, 40], expected: 30 },
  { name: 'two scale-downs, smaller magnitude wins', input: [-20, -40], expected: -20 },
  { name: 'three scale-downs, smallest magnitude wins', input: [-50, -20, -30], expected: -20 },
  { name: 'identical values', input: [30, 30, 30], expected: 30 },
];

let passed = 0;
let failed = 0;

for (const c of cases) {
  const got = pickMostConservativePct(c.input);
  if (got === c.expected) {
    passed++;
    console.log(`  ✓ ${c.name}`);
  } else {
    failed++;
    console.log(`  ✗ ${c.name} — expected ${c.expected}, got ${got}`);
  }
}

// Empty array should throw
try {
  pickMostConservativePct([]);
  failed++;
  console.log('  ✗ empty array — expected throw, got no throw');
} catch {
  passed++;
  console.log('  ✓ empty array throws');
}

console.log(`\n${passed}/${passed + failed} passed`);
if (failed > 0) process.exit(1);
