/**
 * Weekly planner job.
 *
 * Runs every Sunday 8pm AEST via Vercel cron.
 *
 * Steps:
 *  1. Pull last 7 days of insights from Meta.
 *  2. Compute guardrail-suggested action per ad.
 *  3. Ask Claude (analyst prompt) to review + propose final actions
 *     and any new-variant briefs.
 *  4. If new variants requested, ask Claude (copywriter prompt with
 *     AHPRA system prompt) to draft them.
 *  5. If new variants exist, list active adsets + approved creatives,
 *     then ask Claude (placement prompt) to map briefs to adset+asset.
 *  6. Persist the full pending decision to Redis.
 *  7. Send a Telegram approval card.
 *
 * No writes to Meta happen in this job — only reads. Writes are deferred
 * until James approves via Telegram (see apply-decision.ts).
 */

import { randomUUID } from 'crypto';
import { fetchLast7DaysInsights, listActiveAdsets } from '../lib/meta';
import { listApprovedAssets } from '../lib/creative-library';
import { suggestAction, DEFAULT_GUARDRAILS } from '../lib/guardrails';
import { generateJson } from '../lib/claude';
import { redis, keys, PENDING_TTL_SECONDS } from '../lib/redis';
import { sendApprovalCard, sendPlain, formatDecisionCard } from '../lib/telegram';
import { ANALYST_SYSTEM_PROMPT } from '../prompts/analyst';
import { AHPRA_PAID_ADS_SYSTEM_PROMPT } from '../prompts/ahpra-system';
import { PLACEMENT_SYSTEM_PROMPT } from '../prompts/placement';
import type {
  AnalystOutput,
  CopywriterOutput,
  PendingDecision,
  PlacementOutput,
} from '../types/decisions';

export async function runWeeklyPlan(): Promise<{ runId: string }> {
  const runId = randomUUID();

  // 1. Pull insights
  const insights = await fetchLast7DaysInsights();
  if (insights.length === 0) {
    await sendPlain('Weekly plan: no active ads with spend in the last 7 days. Nothing to do.');
    return { runId };
  }

  // 2. Guardrail suggestions (passed to Claude as a hint, not a directive)
  const guardrailHints = insights.map((ad) => ({
    ad_id: ad.ad_id,
    ad_name: ad.ad_name,
    suggested: suggestAction(ad, DEFAULT_GUARDRAILS),
  }));

  // 3. Analyst pass
  const analystUserMsg = JSON.stringify(
    {
      target_cpl_aud: DEFAULT_GUARDRAILS.target_cpl_aud,
      ads: insights,
      guardrail_hints: guardrailHints,
    },
    null,
    2,
  );

  const analystOutput = await generateJson<AnalystOutput>({
    system: ANALYST_SYSTEM_PROMPT,
    user: analystUserMsg,
    maxTokens: 3000,
  });

  // 4. Generate copy for any new-variant briefs
  let generatedCopy: CopywriterOutput | null = null;
  if (analystOutput.new_variant_briefs.length > 0) {
    generatedCopy = await generateJson<CopywriterOutput>({
      system: AHPRA_PAID_ADS_SYSTEM_PROMPT,
      user: `Draft ad copy variants for these briefs. Return one variant per brief.\n\nBriefs:\n${JSON.stringify(analystOutput.new_variant_briefs, null, 2)}`,
      maxTokens: 3000,
    });
  }

  // 5. Placement: map each brief to an adset + creative asset
  let placements: PlacementOutput | null = null;
  if (
    generatedCopy &&
    generatedCopy.variants.length > 0 &&
    analystOutput.new_variant_briefs.length > 0
  ) {
    const [adsets, creatives] = await Promise.all([
      listActiveAdsets(),
      listApprovedAssets(),
    ]);

    if (creatives.length === 0) {
      // No approved creatives → can't place anything. Surface this clearly
      // rather than letting Claude pick from nothing.
      analystOutput.flags_for_human.push(
        '⚠️ No approved creatives in the library — new variants drafted but cannot be created until you approve creative assets.',
      );
    } else {
      const placementUserMsg = JSON.stringify(
        {
          variant_briefs: analystOutput.new_variant_briefs,
          variant_copy: generatedCopy.variants,
          adsets,
          creative_assets: creatives.map((a) => ({
            id: a.id,
            kind: a.kind,
            label: a.label,
            tags: a.tags,
            aspect_ratio: a.aspect_ratio,
          })),
        },
        null,
        2,
      );

      placements = await generateJson<PlacementOutput>({
        system: PLACEMENT_SYSTEM_PROMPT,
        user: placementUserMsg,
        maxTokens: 2000,
      });
    }
  }

  // 6. Persist pending decision (with insights snapshot for the executor)
  const pending: PendingDecision = {
    run_id: runId,
    created_at: new Date().toISOString(),
    insights_snapshot: insights.map((ad) => ({
      ad_id: ad.ad_id,
      adset_id: ad.adset_id,
      ad_name: ad.ad_name,
      spend_aud_7d: ad.spend_aud,
    })),
    analyst_output: analystOutput,
    generated_copy: generatedCopy,
    placements,
    status: 'awaiting_approval',
  };
  await redis.set(keys.pending(runId), pending, { ex: PENDING_TTL_SECONDS });
  await redis.set(keys.lastRun(), runId);

  // 7. Send approval card
  const card = formatDecisionCard({
    runId,
    summary: analystOutput.summary,
    spend: analystOutput.headline_metrics.spend_aud,
    bookings: analystOutput.headline_metrics.bookings_started,
    cpl: analystOutput.headline_metrics.blended_cpl_aud,
    trend: analystOutput.headline_metrics.vs_last_week,
    decisions: analystOutput.ad_decisions
      .filter((d) => d.action !== 'hold')
      .map((d) => ({ ad_name: d.ad_name, action: d.action, reason: d.reason })),
    newVariants: generatedCopy?.variants.length ?? 0,
    flags: analystOutput.flags_for_human,
  });
  await sendApprovalCard({ runId, text: card });

  // Send copy variants in a follow-up message so card stays scannable.
  // Pair each variant with its placement so James can see "this copy →
  // this adset → this creative" in one read.
  if (generatedCopy && generatedCopy.variants.length > 0) {
    const copyMsg = generatedCopy.variants
      .map((v, i) => {
        const p = placements?.placements[i];
        const placementLine = p
          ? p.adset_id && p.creative_asset_id
            ? `_→ adset: ${p.adset_name} · creative: ${p.creative_label} · confidence: ${(p.confidence * 100).toFixed(0)}%_`
            : `_⚠️ unplaced: ${p.human_review_reason ?? 'no match found'}_`
          : '';

        return [
          `*Variant ${i + 1} — ${v.label}*`,
          v.primary_text,
          ``,
          `_Headline:_ ${v.headline}`,
          `_Description:_ ${v.description}`,
          `_CTA:_ ${v.cta}`,
          placementLine,
          v.compliance_notes ? `_⚠️ ${v.compliance_notes}_` : '',
        ]
          .filter(Boolean)
          .join('\n');
      })
      .join('\n\n──────\n\n');
    await sendPlain(copyMsg);
  }

  return { runId };
}
