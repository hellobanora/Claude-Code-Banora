/**
 * Tests for computeClampedBudget — the safety-critical bit of the budget
 * executor. Run with: npx tsx src/lib/__tests__/guardrails.test.ts
 */

import { computeClampedBudget, DEFAULT_GUARDRAILS } from '../guardrails';

interface Case {
  name: string;
  current_cents: number;
  requested_pct: number;
  expected_new_aud: number;
  expected_was_clamped: boolean;
}

const cfg = {
  ...DEFAULT_GUARDRAILS,
  min_daily_budget_aud: 10,
  max_daily_budget_aud: 150,
  max_single_change_pct: 50,
};

const cases: Case[] = [
  {
    name: 'normal +30% scale-up within bounds',
    current_cents: 4000,        // $40
    requested_pct: 30,
    expected_new_aud: 52,
    expected_was_clamped: false,
  },
  {
    name: 'normal -20% scale-down within bounds',
    current_cents: 5000,        // $50
    requested_pct: -20,
    expected_new_aud: 40,
    expected_was_clamped: false,
  },
  {
    name: 'requested change exceeds max_single_change_pct (capped)',
    current_cents: 4000,        // $40
    requested_pct: 200,
    expected_new_aud: 60,       // capped to +50% → $60
    expected_was_clamped: true,
  },
  {
    name: 'result hits max ceiling',
    current_cents: 12000,       // $120
    requested_pct: 50,
    expected_new_aud: 150,      // ceiling
    expected_was_clamped: true,
  },
  {
    name: 'result hits min floor',
    current_cents: 1500,        // $15
    requested_pct: -50,
    expected_new_aud: 10,       // floor
    expected_was_clamped: true,
  },
  {
    name: 'no change',
    current_cents: 5000,
    requested_pct: 0,
    expected_new_aud: 50,
    expected_was_clamped: false,
  },
];

function run() {
  let passed = 0;
  let failed = 0;

  for (const c of cases) {
    const result = computeClampedBudget(c.current_cents, c.requested_pct, cfg);
    const ok =
      result.new_aud === c.expected_new_aud &&
      result.was_clamped === c.expected_was_clamped;

    if (ok) {
      passed++;
      console.log(`  ✓ ${c.name}`);
    } else {
      failed++;
      console.log(`  ✗ ${c.name}`);
      console.log(`    expected new_aud=${c.expected_new_aud} clamped=${c.expected_was_clamped}`);
      console.log(`    got      new_aud=${result.new_aud} clamped=${result.was_clamped}`);
      console.log(`    reason: ${result.clamp_reason ?? '(none)'}`);
    }
  }

  console.log(`\n${passed}/${cases.length} passed`);
  if (failed > 0) process.exit(1);
}

run();
