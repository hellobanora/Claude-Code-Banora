/**
 * Tests for diffPlans.
 * Run with: npx tsx src/lib/__tests__/diff-plans.test.ts
 */

import { diffPlans } from '../diff-plans';
import type { AnalystOutput } from '../../types/decisions';

const baseMetrics = {
  spend_aud: 200,
  link_clicks: 100,
  bookings_started: 5,
  bookings_completed: 3,
  blended_cpl_aud: 40,
  vs_last_week: 'stable' as const,
};

function plan(overrides: Partial<AnalystOutput> = {}): AnalystOutput {
  return {
    summary: 'test',
    headline_metrics: baseMetrics,
    ad_decisions: [
      { ad_id: '1', ad_name: 'Ad One', action: 'pause', budget_change_pct: null, reason: 'CPL high' },
      { ad_id: '2', ad_name: 'Ad Two', action: 'scale_up', budget_change_pct: 30, reason: 'great' },
      { ad_id: '3', ad_name: 'Ad Three', action: 'hold', budget_change_pct: null, reason: 'fine' },
    ],
    new_variant_briefs: [],
    flags_for_human: [],
    ...overrides,
  };
}

let passed = 0;
let failed = 0;

function check(name: string, before: AnalystOutput, after: AnalystOutput, expected: string[]) {
  const got = diffPlans(before, after);
  const combined = got.join(' | ');
  // Empty expected means we expect zero changes
  const ok =
    expected.length === 0
      ? got.length === 0
      : expected.every((e) => combined.includes(e));
  if (ok) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    console.log(`  ✗ ${name}`);
    console.log(`    expected substrings: ${JSON.stringify(expected)}`);
    console.log(`    got:                 ${JSON.stringify(got)}`);
  }
}

// 1. No-op
check('identical plans → no changes', plan(), plan(), []);

// 2. Action change
const after2 = plan({
  ad_decisions: [
    { ad_id: '1', ad_name: 'Ad One', action: 'hold', budget_change_pct: null, reason: 'override' },
    { ad_id: '2', ad_name: 'Ad Two', action: 'scale_up', budget_change_pct: 30, reason: 'great' },
    { ad_id: '3', ad_name: 'Ad Three', action: 'hold', budget_change_pct: null, reason: 'fine' },
  ],
});
check('action change is detected', plan(), after2, ['Ad One', 'pause → hold']);

// 3. Budget percentage change
const after3 = plan({
  ad_decisions: [
    { ad_id: '1', ad_name: 'Ad One', action: 'pause', budget_change_pct: null, reason: 'CPL high' },
    { ad_id: '2', ad_name: 'Ad Two', action: 'scale_up', budget_change_pct: 20, reason: 'tweaked' },
    { ad_id: '3', ad_name: 'Ad Three', action: 'hold', budget_change_pct: null, reason: 'fine' },
  ],
});
check('budget pct change is detected', plan(), after3, ['Ad Two', '+30%', '+20%']);

// 4. Reason-only change should NOT show up
const after4 = plan({
  ad_decisions: [
    { ad_id: '1', ad_name: 'Ad One', action: 'pause', budget_change_pct: null, reason: 'CPL high — reworded' },
    { ad_id: '2', ad_name: 'Ad Two', action: 'scale_up', budget_change_pct: 30, reason: 'still great' },
    { ad_id: '3', ad_name: 'Ad Three', action: 'hold', budget_change_pct: null, reason: 'fine' },
  ],
});
check('reason-only change is not surfaced', plan(), after4, []);

// 5. New variant added
const after5 = plan({
  new_variant_briefs: [
    {
      angle: 'pregnancy back pain',
      rationale: 'requested',
      audience_hint: 'women 25-40',
      objective: 'BookingStarted',
    },
  ],
});
check('new variant brief added is detected', plan(), after5, ['new variants', '0 → 1']);

// 6. Variant angle changed (same count)
const beforeVariants = plan({
  new_variant_briefs: [
    { angle: 'desk workers', rationale: 'r', audience_hint: 'a', objective: 'BookingStarted' },
  ],
});
const afterVariants = plan({
  new_variant_briefs: [
    { angle: 'tradies', rationale: 'r', audience_hint: 'a', objective: 'BookingStarted' },
  ],
});
check('variant angle change is detected', beforeVariants, afterVariants, ['angles revised']);

// 7. Ad removed
const after7: AnalystOutput = {
  ...plan(),
  ad_decisions: plan().ad_decisions.filter((d) => d.ad_id !== '2'),
};
check('removed ad is detected', plan(), after7, ['removed', 'Ad Two']);

console.log(`\n${passed}/${passed + failed} passed`);
if (failed > 0) process.exit(1);
