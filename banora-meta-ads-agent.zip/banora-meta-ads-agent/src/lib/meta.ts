/**
 * Meta Marketing API client.
 *
 * All write operations go through this module so we have one place to
 * audit, rate-limit, and dry-run.
 *
 * Auth: long-lived system user token via META_ACCESS_TOKEN.
 * Required scopes: ads_management, ads_read, pages_manage_ads, business_management.
 */

import type { MetaAdInsights } from './guardrails';

const GRAPH_VERSION = 'v21.0';
const BASE = `https://graph.facebook.com/${GRAPH_VERSION}`;

const accessToken = () => {
  const t = process.env.META_ACCESS_TOKEN;
  if (!t) throw new Error('META_ACCESS_TOKEN not set');
  return t;
};

const adAccountId = () => {
  const id = process.env.META_AD_ACCOUNT_ID;
  if (!id) throw new Error('META_AD_ACCOUNT_ID not set');
  return id.startsWith('act_') ? id : `act_${id}`;
};

/**
 * Fetch the last 7 days of ad-level insights with the fields we need
 * to drive decisions. Returns a normalised shape (MetaAdInsights) so
 * the guardrails layer doesn't have to know about Meta's response shape.
 */
export async function fetchLast7DaysInsights(): Promise<MetaAdInsights[]> {
  const fields = [
    'ad_id',
    'ad_name',
    'adset_id',
    'spend',
    'impressions',
    'inline_link_clicks',
    'ctr',
    'frequency',
    'actions',          // includes our custom conversion events
    'date_start',
    'date_stop',
  ].join(',');

  const url =
    `${BASE}/${adAccountId()}/insights` +
    `?level=ad` +
    `&date_preset=last_7d` +
    `&fields=${fields}` +
    `&access_token=${accessToken()}`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Meta insights fetch failed: ${res.status} ${await res.text()}`);
  }
  const json = (await res.json()) as { data: RawInsight[] };

  // We also need creation date per ad to compute days_live.
  // In production, batch this — one /ads call with ids=... is cheaper.
  const adIds = json.data.map((r) => r.ad_id);
  const adMeta = await fetchAdMeta(adIds);

  // CTR trend requires comparing this week vs last week — implemented
  // as a separate small call. Stubbed here for clarity.
  const trends = await fetchCtrTrends(adIds);

  return json.data.map((row) => {
    const meta = adMeta[row.ad_id];
    const bookingsStarted = extractAction(row.actions, 'BookingStarted');
    const spend = Number(row.spend);
    const cpl = bookingsStarted > 0 ? spend / bookingsStarted : null;

    return {
      ad_id: row.ad_id,
      ad_name: row.ad_name,
      adset_id: row.adset_id,
      days_live: meta?.days_live ?? 0,
      spend_aud: spend,
      impressions: Number(row.impressions),
      link_clicks: Number(row.inline_link_clicks ?? 0),
      ctr: Number(row.ctr) / 100, // Meta returns CTR as percentage
      frequency: Number(row.frequency ?? 0),
      bookings_started: bookingsStarted,
      cpl_aud: cpl,
      ctr_trend: trends[row.ad_id] ?? 'stable',
    };
  });
}

interface RawInsight {
  ad_id: string;
  ad_name: string;
  adset_id: string;
  spend: string;
  impressions: string;
  inline_link_clicks?: string;
  ctr: string;
  frequency?: string;
  actions?: Array<{ action_type: string; value: string }>;
  date_start: string;
  date_stop: string;
}

function extractAction(actions: RawInsight['actions'], type: string): number {
  if (!actions) return 0;
  const match = actions.find((a) => a.action_type === type || a.action_type.endsWith(`.${type}`));
  return match ? Number(match.value) : 0;
}

async function fetchAdMeta(adIds: string[]): Promise<Record<string, { days_live: number }>> {
  if (adIds.length === 0) return {};
  const url =
    `${BASE}/?ids=${adIds.join(',')}` +
    `&fields=created_time,status` +
    `&access_token=${accessToken()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Ad meta fetch failed: ${res.status}`);
  const json = (await res.json()) as Record<string, { created_time: string }>;
  const now = Date.now();
  const out: Record<string, { days_live: number }> = {};
  for (const [id, meta] of Object.entries(json)) {
    const created = new Date(meta.created_time).getTime();
    out[id] = { days_live: Math.floor((now - created) / 86_400_000) };
  }
  return out;
}

async function fetchCtrTrends(
  adIds: string[],
): Promise<Record<string, 'improving' | 'stable' | 'declining'>> {
  // TODO: pull last_14d split by week, compare CTR week-over-week.
  // For the skeleton, return 'stable' for everything so guardrails don't
  // false-trigger refresh suggestions before this is wired up.
  return Object.fromEntries(adIds.map((id) => [id, 'stable' as const]));
}

// ── Write operations ─────────────────────────────────────────────────────

export async function pauseAd(adId: string, dryRun = false): Promise<void> {
  if (dryRun) {
    console.log(`[dry-run] would pause ${adId}`);
    return;
  }
  const url = `${BASE}/${adId}?access_token=${accessToken()}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status: 'PAUSED' }),
  });
  if (!res.ok) throw new Error(`Pause ${adId} failed: ${res.status} ${await res.text()}`);
}

/**
 * Fetch an adset's current daily budget in cents (Meta's native unit).
 * Returns null if the adset uses lifetime budget or campaign budget
 * optimisation (CBO) — in either case, daily_budget will be missing
 * and the caller needs to handle that.
 */
export async function getAdsetDailyBudgetCents(adsetId: string): Promise<number | null> {
  const url = `${BASE}/${adsetId}?fields=daily_budget,lifetime_budget&access_token=${accessToken()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Get adset ${adsetId} failed: ${res.status} ${await res.text()}`);
  const data = (await res.json()) as { daily_budget?: string; lifetime_budget?: string };
  if (!data.daily_budget) return null;
  return Number(data.daily_budget);
}

/**
 * Set an adset's daily budget to an exact value in cents.
 * No clamping or arithmetic happens here — the caller is responsible
 * for computing the safe value via computeClampedBudget().
 */
export async function setAdsetDailyBudgetCents(
  adsetId: string,
  newCents: number,
  dryRun = false,
): Promise<void> {
  if (dryRun) {
    console.log(`[dry-run] would set ${adsetId} daily_budget to ${newCents} cents`);
    return;
  }
  const url = `${BASE}/${adsetId}?access_token=${accessToken()}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ daily_budget: newCents }),
  });
  if (!res.ok) {
    throw new Error(`Set adset ${adsetId} budget failed: ${res.status} ${await res.text()}`);
  }
}

// ── Adset discovery (for variant placement) ──────────────────────────────

export interface AdsetSummary {
  adset_id: string;
  campaign_id: string;
  name: string;
  status: string;                    // 'ACTIVE', 'PAUSED', etc.
  daily_budget_aud: number | null;
  optimisation_goal: string | null;  // e.g. 'LEAD_GENERATION', 'OFFSITE_CONVERSIONS'
  age_min: number | null;
  age_max: number | null;
  /** Count of cities/regions targeted; granular detail is bulky and rarely actionable. */
  geo_summary: string | null;
}

/**
 * List all non-archived adsets in the ad account with the fields Claude
 * needs to pick the right placement for a new variant. We don't return
 * insights here — adset performance is already in the weekly insights pass.
 */
export async function listActiveAdsets(): Promise<AdsetSummary[]> {
  const fields = [
    'id',
    'name',
    'campaign_id',
    'status',
    'daily_budget',
    'optimization_goal',
    'targeting',
  ].join(',');

  const url =
    `${BASE}/${adAccountId()}/adsets` +
    `?fields=${fields}` +
    `&effective_status=["ACTIVE","PAUSED"]` +
    `&limit=100` +
    `&access_token=${accessToken()}`;

  const res = await fetch(url);
  if (!res.ok) throw new Error(`List adsets failed: ${res.status} ${await res.text()}`);
  const json = (await res.json()) as { data: RawAdset[] };

  return json.data.map((row) => {
    const targeting = row.targeting ?? {};
    const geoCounts: string[] = [];
    if (targeting.geo_locations?.cities?.length)
      geoCounts.push(`${targeting.geo_locations.cities.length} cities`);
    if (targeting.geo_locations?.regions?.length)
      geoCounts.push(`${targeting.geo_locations.regions.length} regions`);
    if (targeting.geo_locations?.countries?.length)
      geoCounts.push(targeting.geo_locations.countries.join(','));

    return {
      adset_id: row.id,
      campaign_id: row.campaign_id,
      name: row.name,
      status: row.status,
      daily_budget_aud: row.daily_budget ? Number(row.daily_budget) / 100 : null,
      optimisation_goal: row.optimization_goal ?? null,
      age_min: targeting.age_min ?? null,
      age_max: targeting.age_max ?? null,
      geo_summary: geoCounts.length > 0 ? geoCounts.join(' · ') : null,
    };
  });
}

interface RawAdset {
  id: string;
  name: string;
  campaign_id: string;
  status: string;
  daily_budget?: string;
  optimization_goal?: string;
  targeting?: {
    age_min?: number;
    age_max?: number;
    geo_locations?: {
      cities?: unknown[];
      regions?: unknown[];
      countries?: string[];
    };
  };
}

// ── Ad creation: image and video ─────────────────────────────────────────

export interface CreateAdResult {
  ad_id: string;
  creative_id: string;
}

interface BaseAdArgs {
  adsetId: string;
  name: string;
  primary_text: string;
  headline: string;
  description: string;
  cta: string;
  link_url: string;
  /** Always paused at launch — James reviews in Ads Manager before enabling. */
  dryRun?: boolean;
}

/**
 * Create an image-backed ad. Image must already be uploaded to the ad
 * account; pass the image_hash from /act_X/adimages.
 */
export async function createImageAd(
  args: BaseAdArgs & { image_hash: string },
): Promise<CreateAdResult | null> {
  const pageId = process.env.META_PAGE_ID;
  if (!pageId) throw new Error('META_PAGE_ID not set');

  const creative = {
    object_story_spec: {
      page_id: pageId,
      link_data: {
        message: args.primary_text,
        link: args.link_url,
        name: args.headline,
        description: args.description,
        image_hash: args.image_hash,
        call_to_action: { type: args.cta, value: { link: args.link_url } },
      },
    },
  };

  return finaliseAd(args, creative);
}

/**
 * Create a video-backed ad. Video must already be uploaded to the ad
 * account; pass the video_id from /act_X/advideos.
 *
 * image_url is the thumbnail. If omitted, Meta auto-generates one — but
 * a hand-picked thumbnail almost always outperforms auto-generated.
 */
export async function createVideoAd(
  args: BaseAdArgs & { video_id: string; thumbnail_url?: string },
): Promise<CreateAdResult | null> {
  const pageId = process.env.META_PAGE_ID;
  if (!pageId) throw new Error('META_PAGE_ID not set');

  const creative = {
    object_story_spec: {
      page_id: pageId,
      video_data: {
        video_id: args.video_id,
        title: args.headline,
        message: args.primary_text,
        link_description: args.description,
        image_url: args.thumbnail_url,
        call_to_action: { type: args.cta, value: { link: args.link_url } },
      },
    },
  };

  return finaliseAd(args, creative);
}

/**
 * Shared finaliser — creates the AdCreative then the Ad.
 * Both operations happen sequentially; if creative creation succeeds but
 * ad creation fails, the orphaned creative stays in the account (Meta
 * doesn't auto-clean these). We log the creative_id on failure so the
 * orphan can be tracked down.
 */
async function finaliseAd(
  args: BaseAdArgs,
  creative: unknown,
): Promise<CreateAdResult | null> {
  if (args.dryRun) {
    console.log(`[dry-run] would create ad "${args.name}" in adset ${args.adsetId}`);
    return null;
  }

  // 1. Create the creative
  const creativeRes = await fetch(
    `${BASE}/${adAccountId()}/adcreatives?access_token=${accessToken()}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: `${args.name} — creative`, ...(creative as object) }),
    },
  );
  if (!creativeRes.ok) {
    throw new Error(`Creative create failed: ${creativeRes.status} ${await creativeRes.text()}`);
  }
  const { id: creativeId } = (await creativeRes.json()) as { id: string };

  // 2. Create the ad referencing the creative
  const adRes = await fetch(`${BASE}/${adAccountId()}/ads?access_token=${accessToken()}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: args.name,
      adset_id: args.adsetId,
      creative: { creative_id: creativeId },
      status: 'PAUSED', // hard requirement — James reviews before enabling
    }),
  });
  if (!adRes.ok) {
    throw new Error(
      `Ad create failed (orphaned creative ${creativeId}): ${adRes.status} ${await adRes.text()}`,
    );
  }
  const { id: adId } = (await adRes.json()) as { id: string };
  return { ad_id: adId, creative_id: creativeId };
}
