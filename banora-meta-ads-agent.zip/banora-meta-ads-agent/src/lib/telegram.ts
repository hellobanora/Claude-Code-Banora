/**
 * Telegram bot client.
 *
 * Sends decision cards with inline-keyboard buttons (Approve / Edit / Reject).
 * The webhook at /api/telegram/webhook receives the callback and routes to
 * apply-decision.ts.
 */

const BOT_TOKEN = () => {
  const t = process.env.TELEGRAM_BOT_TOKEN;
  if (!t) throw new Error('TELEGRAM_BOT_TOKEN not set');
  return t;
};

const CHAT_ID = () => {
  const c = process.env.TELEGRAM_CHAT_ID;
  if (!c) throw new Error('TELEGRAM_CHAT_ID not set');
  return c;
};

const API = (method: string) => `https://api.telegram.org/bot${BOT_TOKEN()}/${method}`;

interface InlineButton {
  text: string;
  callback_data: string;
}

export async function sendApprovalCard(args: {
  runId: string;
  text: string;
}): Promise<void> {
  const buttons: InlineButton[][] = [
    [
      { text: '✅ Approve all', callback_data: `approve:${args.runId}` },
      { text: '📝 Edit', callback_data: `edit:${args.runId}` },
    ],
    [{ text: '❌ Reject', callback_data: `reject:${args.runId}` }],
  ];

  const res = await fetch(API('sendMessage'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: CHAT_ID(),
      text: args.text,
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: buttons },
    }),
  });

  if (!res.ok) {
    throw new Error(`Telegram send failed: ${res.status} ${await res.text()}`);
  }
}

export async function sendPlain(text: string): Promise<void> {
  const res = await fetch(API('sendMessage'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: CHAT_ID(),
      text,
      parse_mode: 'Markdown',
    }),
  });
  if (!res.ok) throw new Error(`Telegram send failed: ${res.status}`);
}

/**
 * Format a PendingDecision as a Telegram-friendly Markdown card.
 * Kept short — Telegram has a 4096 char limit and James reads on phone.
 */
export function formatDecisionCard(args: {
  runId: string;
  summary: string;
  spend: number;
  bookings: number;
  cpl: number;
  trend: string;
  decisions: Array<{ ad_name: string; action: string; reason: string }>;
  newVariants: number;
  flags: string[];
}): string {
  const lines: string[] = [];
  lines.push(`*Banora Ads — Weekly Plan*`);
  lines.push(`Run \`${args.runId.slice(0, 8)}\``);
  lines.push('');
  lines.push(args.summary);
  lines.push('');
  lines.push(`*Last 7 days*`);
  lines.push(`Spend: $${args.spend.toFixed(0)} · Bookings: ${args.bookings} · CPL: $${args.cpl.toFixed(0)}`);
  lines.push(`Trend: ${args.trend}`);
  lines.push('');

  if (args.decisions.length > 0) {
    lines.push(`*Proposed actions*`);
    for (const d of args.decisions) {
      const emoji =
        d.action === 'pause' ? '⏸' :
        d.action === 'scale_up' ? '📈' :
        d.action === 'scale_down' ? '📉' :
        d.action === 'refresh' ? '🔄' : '⏯';
      lines.push(`${emoji} *${d.action}* — ${d.ad_name}`);
      lines.push(`   _${d.reason}_`);
    }
    lines.push('');
  }

  if (args.newVariants > 0) {
    lines.push(`*New variants drafted:* ${args.newVariants} (full copy in next message)`);
    lines.push('');
  }

  if (args.flags.length > 0) {
    lines.push(`*⚠️ Flags*`);
    for (const f of args.flags) lines.push(`• ${f}`);
  }

  return lines.join('\n');
}
