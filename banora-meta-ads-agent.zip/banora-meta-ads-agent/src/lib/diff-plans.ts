/**
 * Plan diff utility. Pure function — no side effects, easy to test.
 *
 * Compares two AnalystOutput plans and returns a list of human-readable
 * change strings. Used to build the "you changed:" section of the
 * revised approval card.
 */

import type { AnalystOutput, AdDecision } from '../types/decisions';

export function diffPlans(before: AnalystOutput, after: AnalystOutput): string[] {
  const changes: string[] = [];

  // Index decisions by ad_id for cross-lookup
  const beforeByAd = new Map(before.ad_decisions.map((d) => [d.ad_id, d]));
  const afterByAd = new Map(after.ad_decisions.map((d) => [d.ad_id, d]));

  // Walk every ad referenced in either plan
  const allAdIds = new Set([...beforeByAd.keys(), ...afterByAd.keys()]);
  for (const adId of allAdIds) {
    const b = beforeByAd.get(adId);
    const a = afterByAd.get(adId);

    if (b && !a) {
      changes.push(`removed: ${b.ad_name} (${b.action})`);
      continue;
    }
    if (!b && a) {
      changes.push(`added: ${a.ad_name} (${a.action})`);
      continue;
    }
    if (!b || !a) continue;

    if (b.action !== a.action) {
      changes.push(`${a.ad_name}: ${b.action} → ${a.action}`);
    } else if (b.budget_change_pct !== a.budget_change_pct) {
      const fmt = (v: number | null) => (v === null ? '—' : `${v >= 0 ? '+' : ''}${v}%`);
      changes.push(`${a.ad_name}: budget ${fmt(b.budget_change_pct)} → ${fmt(a.budget_change_pct)}`);
    }
    // Reason changes alone aren't worth surfacing — they're often just
    // wording tweaks. Action and budget changes are what matter.
  }

  // New variant briefs — count change
  if (before.new_variant_briefs.length !== after.new_variant_briefs.length) {
    changes.push(
      `new variants: ${before.new_variant_briefs.length} → ${after.new_variant_briefs.length}`,
    );
  } else {
    // Same count, but check angles changed
    const beforeAngles = before.new_variant_briefs.map((v) => v.angle).join('|');
    const afterAngles = after.new_variant_briefs.map((v) => v.angle).join('|');
    if (beforeAngles !== afterAngles) {
      changes.push('new variants: angles revised');
    }
  }

  // Flags
  const beforeFlags = before.flags_for_human.join('|');
  const afterFlags = after.flags_for_human.join('|');
  if (beforeFlags !== afterFlags) {
    changes.push('flags revised');
  }

  return changes;
}
