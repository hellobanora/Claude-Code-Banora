/**
 * Guardrails — numeric decision thresholds.
 *
 * Tuned conservatively for a small-budget single-clinic account. Adjust
 * once you have 4+ weeks of data. All thresholds are expressed in plain
 * config so non-engineers can edit without touching logic.
 */

import type { AdAction } from '../types/decisions';

export interface MetaAdInsights {
  ad_id: string;
  ad_name: string;
  adset_id: string;
  days_live: number;
  spend_aud: number;
  impressions: number;
  link_clicks: number;
  ctr: number;             // 0.012 = 1.2%
  frequency: number;
  bookings_started: number;
  cpl_aud: number | null;  // null if zero conversions
  ctr_trend: 'improving' | 'stable' | 'declining';
}

export interface GuardrailConfig {
  target_cpl_aud: number;
  learning_min_clicks: number;
  learning_min_days: number;
  pause_cpl_multiplier: number;          // pause if cpl > this × target
  pause_ctr_threshold: number;           // 0.008 = 0.8%
  pause_ctr_min_impressions: number;
  refresh_frequency_threshold: number;
  scale_up_cpl_multiplier: number;       // scale if cpl ≤ this × target
  scale_up_pct: number;
  scale_down_cpl_multiplier: number;     // soft scale-down if cpl drifting up
  scale_down_pct: number;
  // Budget safety bounds — applied AFTER any scale_up/scale_down decision.
  // Meta accepts wild values; these protect against typos and runaway
  // compounding from repeated weekly scale-ups.
  min_daily_budget_aud: number;
  max_daily_budget_aud: number;
  max_single_change_pct: number;         // refuse to apply > this % in one go
}

export const DEFAULT_GUARDRAILS: GuardrailConfig = {
  target_cpl_aud: Number(process.env.TARGET_CPL_AUD ?? 45),
  learning_min_clicks: 50,
  learning_min_days: 3,
  pause_cpl_multiplier: 2.0,
  pause_ctr_threshold: 0.008,
  pause_ctr_min_impressions: 1000,
  refresh_frequency_threshold: 3.0,
  scale_up_cpl_multiplier: 0.7,
  scale_up_pct: 30,
  scale_down_cpl_multiplier: 1.4,
  scale_down_pct: 20,
  min_daily_budget_aud: Number(process.env.MIN_DAILY_BUDGET_AUD ?? 10),
  max_daily_budget_aud: Number(process.env.MAX_DAILY_BUDGET_AUD ?? 150),
  max_single_change_pct: 50,
};

export interface GuardrailSuggestion {
  action: AdAction;
  budget_change_pct: number | null;
  reason: string;
}

/**
 * Pure function: given metrics + config, suggest the default action.
 * Claude can override this in the analyst step — but we always show
 * the heuristic suggestion alongside Claude's choice in the Telegram card.
 */
export function suggestAction(
  ad: MetaAdInsights,
  cfg: GuardrailConfig = DEFAULT_GUARDRAILS,
): GuardrailSuggestion {
  // Learning phase — never pause, never scale
  if (ad.days_live < cfg.learning_min_days || ad.link_clicks < cfg.learning_min_clicks) {
    return {
      action: 'hold',
      budget_change_pct: null,
      reason: `Still in learning (${ad.days_live}d live, ${ad.link_clicks} clicks)`,
    };
  }

  // Pause: CPL way above target
  if (ad.cpl_aud !== null && ad.cpl_aud > cfg.target_cpl_aud * cfg.pause_cpl_multiplier) {
    return {
      action: 'pause',
      budget_change_pct: null,
      reason: `CPL $${ad.cpl_aud.toFixed(0)} > ${cfg.pause_cpl_multiplier}× target ($${cfg.target_cpl_aud})`,
    };
  }

  // Pause: CTR below threshold with enough impressions to trust the signal
  if (ad.impressions >= cfg.pause_ctr_min_impressions && ad.ctr < cfg.pause_ctr_threshold) {
    return {
      action: 'pause',
      budget_change_pct: null,
      reason: `CTR ${(ad.ctr * 100).toFixed(2)}% below ${(cfg.pause_ctr_threshold * 100).toFixed(1)}% over ${ad.impressions} impressions`,
    };
  }

  // Refresh: creative fatigue
  if (ad.frequency > cfg.refresh_frequency_threshold && ad.ctr_trend === 'declining') {
    return {
      action: 'refresh',
      budget_change_pct: null,
      reason: `Frequency ${ad.frequency.toFixed(1)} with declining CTR — creative fatigue`,
    };
  }

  // Scale up: CPL well below target
  if (ad.cpl_aud !== null && ad.cpl_aud <= cfg.target_cpl_aud * cfg.scale_up_cpl_multiplier) {
    return {
      action: 'scale_up',
      budget_change_pct: cfg.scale_up_pct,
      reason: `CPL $${ad.cpl_aud.toFixed(0)} well under target — scale +${cfg.scale_up_pct}%`,
    };
  }

  // Soft scale down: CPL drifting up but not pause-worthy
  if (ad.cpl_aud !== null && ad.cpl_aud > cfg.target_cpl_aud * cfg.scale_down_cpl_multiplier) {
    return {
      action: 'scale_down',
      budget_change_pct: -cfg.scale_down_pct,
      reason: `CPL drifting above target — trim ${cfg.scale_down_pct}%`,
    };
  }

  return {
    action: 'hold',
    budget_change_pct: null,
    reason: 'Performing within band',
  };
}

// ── Budget clamping ──────────────────────────────────────────────────────

export interface ClampedBudgetResult {
  /** Original daily budget in AUD (converted from Meta's minor units). */
  current_aud: number;
  /** New daily budget in AUD after clamping. */
  new_aud: number;
  /** New daily budget in cents — what we send to Meta. */
  new_cents: number;
  /** Effective change percentage after clamping. */
  effective_change_pct: number;
  /** True if the requested change had to be clamped. */
  was_clamped: boolean;
  /** Human-readable reason for the clamp, if any. */
  clamp_reason: string | null;
}

/**
 * Compute the safe new daily budget for an adset given a requested
 * percentage change.
 *
 * Rules applied (in order):
 *   1. Refuse to apply changes > max_single_change_pct in a single run.
 *   2. Clamp the result to [min_daily_budget_aud, max_daily_budget_aud].
 *   3. Round to whole AUD (Meta accepts cents, but whole-dollar budgets
 *      are easier to read in reporting and don't lose anything material).
 *
 * The current budget is passed in as cents (Meta's native unit) so the
 * caller doesn't have to know about the conversion.
 */
export function computeClampedBudget(
  currentCents: number,
  requestedChangePct: number,
  cfg: GuardrailConfig = DEFAULT_GUARDRAILS,
): ClampedBudgetResult {
  const currentAud = currentCents / 100;

  // 1. Cap the requested change magnitude
  let cappedPct = requestedChangePct;
  let clampReason: string | null = null;
  if (Math.abs(requestedChangePct) > cfg.max_single_change_pct) {
    cappedPct = Math.sign(requestedChangePct) * cfg.max_single_change_pct;
    clampReason = `Requested ${requestedChangePct.toFixed(0)}% capped at ±${cfg.max_single_change_pct}%`;
  }

  // 2. Apply, then clamp to absolute bounds
  let newAud = Math.round(currentAud * (1 + cappedPct / 100));
  if (newAud < cfg.min_daily_budget_aud) {
    newAud = cfg.min_daily_budget_aud;
    clampReason = `Clamped to floor $${cfg.min_daily_budget_aud}`;
  } else if (newAud > cfg.max_daily_budget_aud) {
    newAud = cfg.max_daily_budget_aud;
    clampReason = `Clamped to ceiling $${cfg.max_daily_budget_aud}`;
  }

  const effectivePct = ((newAud - currentAud) / currentAud) * 100;

  return {
    current_aud: currentAud,
    new_aud: newAud,
    new_cents: newAud * 100,
    effective_change_pct: effectivePct,
    was_clamped: clampReason !== null,
    clamp_reason: clampReason,
  };
}
