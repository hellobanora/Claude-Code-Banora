/**
 * Upstash Redis (REST) client + key helpers.
 * Same provider/pattern as banora-social-autopilot.
 */

import { Redis } from '@upstash/redis';

export const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

export const keys = {
  pending: (runId: string) => `meta-ads:pending:${runId}`,
  history: (runId: string) => `meta-ads:history:${runId}`,
  lastRun: () => `meta-ads:last-run`,
  // When James taps Edit, we pin the chat to a run for a short window so
  // his next plain-text message is treated as edit instructions.
  awaitingEdit: (chatId: string) => `meta-ads:awaiting-edit:${chatId}`,
};

// Pending approvals expire after 7 days — if James hasn't approved by
// then, we don't want stale state cluttering the system.
export const PENDING_TTL_SECONDS = 7 * 24 * 60 * 60;

// Edit-mode pin: short window. If James taps Edit and gets distracted,
// his unrelated message an hour later shouldn't be parsed as an edit.
export const AWAITING_EDIT_TTL_SECONDS = 30 * 60;
