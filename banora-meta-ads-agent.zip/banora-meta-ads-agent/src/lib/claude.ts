/**
 * Thin wrapper around the Anthropic SDK that:
 * - Pins the model to claude-sonnet-4 (matches banora-social-autopilot)
 * - Forces JSON-only output for prompts that expect structured data
 * - Strips accidental markdown fences before parsing
 */

import Anthropic from '@anthropic-ai/sdk';

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const MODEL = 'claude-sonnet-4-20250514';

export async function generateJson<T>(args: {
  system: string;
  user: string;
  maxTokens?: number;
}): Promise<T> {
  const res = await client.messages.create({
    model: MODEL,
    max_tokens: args.maxTokens ?? 4000,
    system: args.system,
    messages: [{ role: 'user', content: args.user }],
  });

  const textBlock = res.content.find((b): b is Anthropic.TextBlock => b.type === 'text');
  if (!textBlock) throw new Error('Claude returned no text content');

  const cleaned = textBlock.text
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/```$/, '')
    .trim();

  try {
    return JSON.parse(cleaned) as T;
  } catch (err) {
    throw new Error(
      `Failed to parse Claude JSON output. First 500 chars:\n${cleaned.slice(0, 500)}\n\nError: ${err}`,
    );
  }
}
