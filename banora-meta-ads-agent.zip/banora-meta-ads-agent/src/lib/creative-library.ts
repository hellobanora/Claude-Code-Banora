/**
 * Creative library — unified catalogue of approved media (images, videos)
 * the agent can pick from when creating new ads.
 *
 * Why a library, not direct uploads in the loop:
 *   1. AHPRA-sensitive. Every piece of creative needs human approval
 *      before it can be used in an ad. The library is where that
 *      approval is recorded.
 *   2. Reusable. The same image can back multiple ad variants targeting
 *      different angles, without re-uploading.
 *   3. Auditable. We can answer "where did the image in this ad come
 *      from" months later by looking up the library entry.
 *
 * Lifecycle:
 *   1. James (or a future Telegram upload flow) adds a CreativeAsset to
 *      the library with status 'pending'.
 *   2. James reviews and flips status to 'approved' (or rejects it).
 *   3. The agent only ever picks from approved entries.
 *   4. Entries can be archived (status 'archived') without deletion so
 *      historical ad audits still work.
 */

import { redis } from './redis';

export type CreativeKind = 'image' | 'video';
export type CreativeStatus = 'pending' | 'approved' | 'archived';

export interface CreativeAsset {
  /** Internal ID. Independent of Meta's hash/video ID so we can re-upload if needed. */
  id: string;
  kind: CreativeKind;
  /**
   * Meta's identifier for this asset:
   *   - For images: the image_hash from /act_X/adimages
   *   - For videos: the video_id from /act_X/advideos
   */
  meta_ref: string;
  /** Human-readable label, e.g. "James in clinic — wide" or "Patient walking out smiling — 15s". */
  label: string;
  /**
   * Tags for matching against variant briefs. Keep these meaningful:
   *   audience: 'desk-workers', 'tradies', 'parents', 'general'
   *   mood: 'calm', 'energetic', 'professional'
   *   subject: 'james', 'paul', 'clinic', 'lifestyle'
   *   format: 'square', 'vertical', 'horizontal'
   *   condition: 'low-back', 'neck', 'headaches', 'general'
   * Tags are free-form strings — the conventions above are for consistency,
   * not enforced by code.
   */
  tags: string[];
  /** Source for audit: 'in-house' (you filmed/photographed), 'ai-generated', 'stock', 'patient-consented'. */
  source: string;
  /** Square or vertical works on more placements. Recorded for reference. */
  aspect_ratio?: '1:1' | '4:5' | '9:16' | '16:9';
  /** Who approved this and when. Set when status flips to 'approved'. */
  approved_by?: string;
  approved_at?: string;
  status: CreativeStatus;
  /** Free-text notes — e.g. "do not use for targeting under 18", "post-Bali". */
  notes?: string;
  created_at: string;
}

const KEY_INDEX = 'meta-ads:creatives:index';
const keyForAsset = (id: string) => `meta-ads:creatives:asset:${id}`;

export async function addAsset(asset: Omit<CreativeAsset, 'created_at'>): Promise<void> {
  const full: CreativeAsset = { ...asset, created_at: new Date().toISOString() };
  await redis.set(keyForAsset(full.id), full);
  await redis.sadd(KEY_INDEX, full.id);
}

export async function getAsset(id: string): Promise<CreativeAsset | null> {
  return (await redis.get(keyForAsset(id))) as CreativeAsset | null;
}

export async function updateAssetStatus(
  id: string,
  status: CreativeStatus,
  approvedBy?: string,
): Promise<void> {
  const a = await getAsset(id);
  if (!a) throw new Error(`Asset ${id} not found`);
  a.status = status;
  if (status === 'approved') {
    a.approved_by = approvedBy ?? 'james';
    a.approved_at = new Date().toISOString();
  }
  await redis.set(keyForAsset(id), a);
}

/**
 * Return all assets currently 'approved' — what the agent can pick from.
 * Optionally filter by kind (image-only vs video-only) and/or by tags
 * (any-of match: at least one tag must overlap).
 */
export async function listApprovedAssets(filter?: {
  kind?: CreativeKind;
  anyOfTags?: string[];
}): Promise<CreativeAsset[]> {
  const ids = (await redis.smembers(KEY_INDEX)) as string[];
  if (ids.length === 0) return [];

  // Upstash supports mget; one round trip beats N gets.
  const keys = ids.map(keyForAsset);
  const raw = (await redis.mget(...keys)) as Array<CreativeAsset | null>;
  const all = raw.filter((a): a is CreativeAsset => a !== null && a.status === 'approved');

  let filtered = all;
  if (filter?.kind) filtered = filtered.filter((a) => a.kind === filter.kind);
  if (filter?.anyOfTags && filter.anyOfTags.length > 0) {
    const wanted = new Set(filter.anyOfTags.map((t) => t.toLowerCase()));
    filtered = filtered.filter((a) =>
      a.tags.some((t) => wanted.has(t.toLowerCase())),
    );
  }
  return filtered;
}
