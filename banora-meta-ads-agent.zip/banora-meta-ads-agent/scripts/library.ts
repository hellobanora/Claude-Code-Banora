/**
 * CLI for managing the creative library.
 *
 * Typical workflow for a new image:
 *   1. Upload the image to Meta:
 *      curl -F "filename=@path/to/image.jpg" \
 *           "https://graph.facebook.com/v21.0/act_XXX/adimages?access_token=$META_ACCESS_TOKEN"
 *      → returns { "images": { "image.jpg": { "hash": "abc123..." } } }
 *
 *   2. Add to library (status defaults to 'pending'):
 *      npx tsx scripts/library.ts add image abc123 \
 *        --label "James in clinic, wide" \
 *        --tags "james,clinic,professional,square" \
 *        --source "in-house" \
 *        --aspect 1:1
 *
 *   3. Review and approve:
 *      npx tsx scripts/library.ts list
 *      npx tsx scripts/library.ts approve <id>
 *
 * Videos work the same way but use kind 'video' and the video_id from
 * /act_X/advideos instead of an image_hash.
 */

import { randomUUID } from 'crypto';
import {
  addAsset,
  getAsset,
  listApprovedAssets,
  updateAssetStatus,
  type CreativeAsset,
  type CreativeKind,
} from '../src/lib/creative-library';
import { redis } from '../src/lib/redis';

function parseFlags(argv: string[]): Record<string, string> {
  const flags: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const val = argv[i + 1];
      if (val && !val.startsWith('--')) {
        flags[key] = val;
        i++;
      }
    }
  }
  return flags;
}

async function cmdAdd(kind: CreativeKind, metaRef: string, flags: Record<string, string>) {
  if (!flags.label) throw new Error('--label is required');
  if (!flags.tags) throw new Error('--tags is required (comma-separated)');
  if (!flags.source) throw new Error('--source is required');

  const id = `cre_${randomUUID().slice(0, 8)}`;
  await addAsset({
    id,
    kind,
    meta_ref: metaRef,
    label: flags.label,
    tags: flags.tags.split(',').map((t) => t.trim()).filter(Boolean),
    source: flags.source,
    aspect_ratio: flags.aspect as CreativeAsset['aspect_ratio'],
    status: 'pending',
    notes: flags.notes,
  });
  console.log(`Added ${id} (${kind}, status=pending). Run 'approve ${id}' once you've reviewed it.`);
}

async function cmdApprove(id: string) {
  await updateAssetStatus(id, 'approved');
  const a = await getAsset(id);
  console.log(`Approved ${id}: ${a?.label}`);
}

async function cmdArchive(id: string) {
  await updateAssetStatus(id, 'archived');
  console.log(`Archived ${id}`);
}

async function cmdList(filter?: 'all' | 'approved' | 'pending') {
  // Pull all by walking the index regardless of status when 'all'
  const all = (await redis.smembers('meta-ads:creatives:index')) as string[];
  if (all.length === 0) {
    console.log('Library is empty.');
    return;
  }

  const assets = await Promise.all(all.map((id) => getAsset(id)));
  const filtered = assets.filter((a): a is CreativeAsset => {
    if (!a) return false;
    if (!filter || filter === 'all') return true;
    return a.status === filter;
  });

  if (filtered.length === 0) {
    console.log(`No assets matching filter '${filter}'.`);
    return;
  }

  for (const a of filtered) {
    const tags = a.tags.join(', ');
    console.log(
      `${a.id}  ${a.kind.padEnd(5)}  ${a.status.padEnd(8)}  ${a.label}\n  tags: ${tags}\n  source: ${a.source}, ref: ${a.meta_ref}\n`,
    );
  }
  console.log(`${filtered.length} of ${assets.length} shown.`);
}

async function main() {
  const [, , cmd, ...rest] = process.argv;

  switch (cmd) {
    case 'add': {
      const [kind, metaRef, ...flagArgs] = rest;
      if (kind !== 'image' && kind !== 'video') {
        console.error('Usage: library.ts add <image|video> <meta_ref> [flags]');
        process.exit(1);
      }
      if (!metaRef) {
        console.error('meta_ref required');
        process.exit(1);
      }
      await cmdAdd(kind, metaRef, parseFlags(flagArgs));
      break;
    }
    case 'approve':
      if (!rest[0]) {
        console.error('Usage: library.ts approve <id>');
        process.exit(1);
      }
      await cmdApprove(rest[0]);
      break;
    case 'archive':
      if (!rest[0]) {
        console.error('Usage: library.ts archive <id>');
        process.exit(1);
      }
      await cmdArchive(rest[0]);
      break;
    case 'list':
      await cmdList((rest[0] as 'all' | 'approved' | 'pending') ?? 'all');
      break;
    default:
      console.log(
        [
          'Usage:',
          '  library.ts add <image|video> <meta_ref> --label "..." --tags "a,b,c" --source "..." [--aspect 1:1] [--notes "..."]',
          '  library.ts approve <id>',
          '  library.ts archive <id>',
          '  library.ts list [all|approved|pending]',
        ].join('\n'),
      );
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
